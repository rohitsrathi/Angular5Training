export class Book {

    id;
    name;
    author;
    price;

}